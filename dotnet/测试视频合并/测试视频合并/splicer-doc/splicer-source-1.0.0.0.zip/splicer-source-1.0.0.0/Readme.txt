Splicer for .Net

Splicer is a library for the .Net framework that aims to simplify 
developing applications for editing and encoding audio and video 
using DirectShow.

For more info please see:

http://www.codeplex.com/splicer

Or more my blog for the latest news:

http://blog.bittercoder.com