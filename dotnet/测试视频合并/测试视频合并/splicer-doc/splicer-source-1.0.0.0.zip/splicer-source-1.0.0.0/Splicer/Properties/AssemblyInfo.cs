﻿using System;
using System.Reflection;
using System.Security.Permissions;

[assembly : AssemblyTitle("Splicer")]
[assembly: AssemblyDescription("A video manipulation library based on DirectShow.Net, originally developed by Alex Henderson http://blog.bittercoder.com/")]
[assembly : CLSCompliant(true)]
[assembly : SecurityPermission(SecurityAction.RequestMinimum, UnmanagedCode = true)]